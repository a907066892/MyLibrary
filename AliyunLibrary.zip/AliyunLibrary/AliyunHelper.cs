﻿using Aliyun.Acs.Core;
using Aliyun.Acs.Core.Profile;
using Aliyun.Acs.Iot.Model.V20180120;
using AliyunLibrary.AliyunEnum;
using AliyunLibrary.Config;
using Aliyun.Acs.Cloudauth.Model.V20190307;
using AliyunLibrary.Service;
using System;

namespace AliyunLibrary
{

    public class AliyunHelper
    {
        public AliyunConfig Config { get; set; }
        private DefaultAcsClient _client;

        private AliyunHelper(AliyunConfig config, bool isIot = false)
        {
            Config = config;
            ///初始化api客户端
            DefaultProfile profile = DefaultProfile.GetProfile(config.RegionId, config.AccessKeyId, config.AccessKeySecret);

            DefaultAcsClient client = new DefaultAcsClient(profile);
            _client = client;
        }

       

        public static AliyunHelper GetInstance(AliyunConfig config)
        {
            AliyunHelper aliyunHelper = new AliyunHelper(config);
            return aliyunHelper;
        }

 

        /// <summary>
        /// 获取对应服务类
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public  static T GetServer<T>(AliyunConfig config) where T : AliServerBase
        {

            return (T)Activator.CreateInstance(typeof(T), config);
        }

        


        #region 人脸SDK授权

        /// <summary>
        /// 异步sdk下载（根据apk）
        /// 返回taskid  后续通过DescribeVerifySDK方法查询异步下载状态 获取sdk下载地址
        /// </summary>
        /// <returns>taskid </returns>
        public string VerifySDK(string sAppUrl)
        {

            CreateVerifySDKResponse response = null;

            //构建请求
            CreateVerifySDKRequest request = new CreateVerifySDKRequest();
            request.AppUrl = sAppUrl;

            response = _client.GetAcsResponse(request);

            return response.TaskId;
        }

        /// <summary>
        /// 查询下载状态
        /// </summary>
        /// <param name="sTaskId">异步下载taskId</param>
        /// <returns></returns>
        public string DescribeVerifySDK(string sTaskId)
        {
            DescribeVerifySDKRequest request = new DescribeVerifySDKRequest();
            DescribeVerifySDKResponse response = null;

            request.TaskId = sTaskId;

            response = _client.GetAcsResponse(request);


            return response.SdkUrl;
        }


        /// <summary>
        /// 获取授权key
        /// </summary>
        /// <returns>AuthKey</returns>
        public string CreateAuthKey(string sBizType, string sDeviceId, int nAuthYears, bool bTest)
        {
            CreateAuthKeyRequest request = new CreateAuthKeyRequest();
            CreateAuthKeyResponse response = null;

            request.BizType = sBizType;
            request.UserDeviceId = sDeviceId;
            request.Test = bTest;
            request.AuthYears = nAuthYears;

            response = _client.GetAcsResponse(request);


            return response.AuthKey;
        }

        /// <summary>
        /// 获取测试授权key
        /// </summary>
        /// <returns>AuthKey</returns>
        public string CreateTestAuthKey(string sBizType, string sDeviceId)
        {
            CreateAuthKeyRequest request = new CreateAuthKeyRequest();
            CreateAuthKeyResponse response = null;

            request.BizType = sBizType;
            request.UserDeviceId = sDeviceId;
            request.Test = true;

            response = _client.GetAcsResponse(request);


            return response.AuthKey;
        }

        #endregion


        #region IOT管理



        /// <summary>
        /// 创建产品
        /// </summary>
        public CreateProductResponse CreateProduct(string sProductName, Enums.NodeType nodeType, string sNetType)
        {
            CreateProductRequest request = new CreateProductRequest();
            request.ProductName = sProductName;
            request.NodeType = (int)nodeType;
            // request.NetType = sNetType;

            CreateProductResponse response = _client.GetAcsResponse(request);



            return response;
        }
        public void DeleteProduct()
        {

        }

        /// <summary>
        /// 获取产品 分页
        /// </summary>
        /// <param name="currentPage"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public QueryProductListResponse GetProductList(int currentPage, int pageSize)
        {
            QueryProductListRequest reqeust = new QueryProductListRequest();
            reqeust.PageSize = pageSize;
            reqeust.CurrentPage = currentPage;
            QueryProductListResponse response = _client.GetAcsResponse(reqeust);

            return response;

        }



        /// <summary>
        /// 注册设备
        /// </summary>
        /// <param name="sProductKey">产品key</param>
        /// <param name="sDeviceName">产品名称</param>
        /// <returns></returns>
        public RegisterDeviceResponse CreateDevice(string sProductKey, string sDeviceName)
        {
            RegisterDeviceRequest request = new RegisterDeviceRequest();
            request.ProductKey = sProductKey;
            request.DeviceName = sDeviceName;

            RegisterDeviceResponse response = _client.GetAcsResponse(request);
            return response;
        }

        /// <summary>
        /// 删除设备
        /// </summary>
        /// <param name="sProductKey">产品key</param>
        /// <param name="sDeviceName">产品名称</param>
        /// <returns></returns>
        public DeleteDeviceResponse DeleteDevice(string sIotId)
        {
            DeleteDeviceRequest request = new DeleteDeviceRequest();
            request.IotId = sIotId;

            DeleteDeviceResponse response = _client.GetAcsResponse(request);


            return response;
        }

        #endregion


    }



}
