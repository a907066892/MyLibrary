﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AliyunLibrary.AliyunEnum
{
   public static class Enums
    {
        public enum NodeType
        {
            /// <summary>
            /// 设备
            /// </summary>
            Equipment = 0,
            /// <summary>
            /// 网关
            /// </summary>
            Gateway = 1
        }

        public enum NetType
        {
            WIFI,
            CELLULAR,
            ETHERNET,
            LORA,
            OTHER
        }

    }
}
