﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AliyunLibrary.Config
{
    public class AliyunConfig
    {
        public AliyunConfig(string regionId, string accessKeyId, string accessKeySecret)
        {
            RegionId = regionId;
            AccessKeyId = accessKeyId;
            AccessKeySecret = accessKeySecret;
        }
        public string RegionId { get; set; }

        public string AccessKeyId { get; set; }

        public string AccessKeySecret { get; set; }
    }
}
