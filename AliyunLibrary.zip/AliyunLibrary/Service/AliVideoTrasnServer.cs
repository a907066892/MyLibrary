﻿using Aliyun.Acs.Core;
using Aliyun.Acs.Core.Http;
using AliyunLibrary.Config;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AliyunLibrary.Service
{
    public class AliVideoTrasnServer : AliServerBase
    {
        private const string DOMAIN = "filetrans.cn-shanghai.aliyuncs.com";
        private const string API_VERSION = "2018-08-17";
        private const string POST_REQUEST_ACTION = "SubmitTask";
        private const string GET_REQUEST_ACTION = "GetTaskResult";
        public const string PRODUCT = "nls-filetrans";
        public AliVideoTrasnServer(AliyunConfig config) : base(config)
        {
        }


        public string SubmitFile(string fileLink, Action<string> errorOpeation)
        {
            CommonRequest request = new CommonRequest();
            request.Domain = DOMAIN;
            request.Version = API_VERSION;
            request.Action = POST_REQUEST_ACTION;
            request.Product = PRODUCT;
            request.Method = MethodType.POST;


            JObject json = new JObject();
            json["appkey"] = "BY3ISxmILJPZG1Yp";
            json["file_link"] = fileLink;
            json["version"] = "4.0";
            json["enable_words"] = false;
            request.AddBodyParameters("Task", json.ToString());

            CommonResponse response = _client.GetCommonResponse(request);
            if (response.HttpStatus != 200)
            {
                errorOpeation(response.Data);
            }

            return response.Data;
        }

        public string GetTask(string taskId, Action<string> errorOperation)
        {
            CommonRequest request = new CommonRequest();
            request.Domain = DOMAIN;
            request.Version = API_VERSION;
            request.Action = GET_REQUEST_ACTION;
            request.Product = PRODUCT;
            request.Method = MethodType.GET;

            request.AddQueryParameters("TaskId", taskId);

            var Result = WhileGet(request, errorOperation);

            return Result;
        }

        public string WhileGet(CommonRequest request, Action<string> errorOpration)
        {
            DateTime now = DateTime.Now;
            CommonResponse response = new CommonResponse();
            JObject json = new JObject();
            string status = "RUNNING";
            while ((status != "RUNNING" || status != "QUEUEING") && DateTime.Now.Subtract(now).TotalSeconds < 5)
            {
                response = _client.GetCommonResponse(request);
                json = JObject.Parse(response.Data);
                status = json["StatusText"].ToString();

                if (response.HttpStatus != 200)
                {
                    errorOpration(response.Data);
                    break;
                }
                Thread.Sleep(100);
            }

            if (status.Replace("\"", "") == "SUCCESS")
            {
                return json["Result"].ToString().Replace("\"", "");
            }
            else
            {
                errorOpration(response.Data);
                return status;
            }
        }

    }
}
