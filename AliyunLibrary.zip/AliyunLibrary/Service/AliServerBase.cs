﻿using Aliyun.Acs.Core;
using Aliyun.Acs.Core.Profile;
using AliyunLibrary.Config;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AliyunLibrary.Service
{
    public abstract class AliServerBase
    {
        /// <summary>
        /// 阿里 sdk 服务实例对象
        /// </summary>
        protected AliyunConfig _config;
        protected IClientProfile _profile;
        protected IAcsClient _client;


        public AliServerBase(AliyunConfig config)
        {
            if (config == null)
                _config = BuilderConfig();
            _config = config;

            _profile = BuilderProfile(_config);
            _client= BuilderClient(_profile);
        }

        /// <summary>
        /// 替换配置文件 用来构建 Profile
        /// </summary>
        protected virtual AliyunConfig BuilderConfig()
        {
            return _config;
        }

        /// <summary>
        /// 构建Profile 用来创建aliyun client
        /// </summary>
        /// <param name="config"></param>
        /// <returns></returns>
        protected virtual IClientProfile BuilderProfile(AliyunConfig config)
        {
            return DefaultProfile.GetProfile(config.RegionId, config.AccessKeyId, config.AccessKeySecret);
        }

        /// <summary>
        /// 构建aliyun Client  用来执行调用阿里api
        /// </summary>
        /// <param name="profile"></param>
        /// <returns></returns>
        protected virtual IAcsClient BuilderClient(IClientProfile profile)
        {
            DefaultAcsClient client = new DefaultAcsClient(profile);
            return client;
        }


    }
}
